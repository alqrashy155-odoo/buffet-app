// ============================================================
//  إعدادات التطبيق — عدّل هذا الملف فقط
//  القيم من: Supabase → Project Settings → API
//    SUPABASE_URL      = Project URL
//    SUPABASE_ANON_KEY = anon / public key  (آمن للنشر — الحماية عبر RLS)
//  إذا تُركت فارغة يعمل التطبيق في وضع تجريبي محلي.
// ============================================================
window.APP_CONFIG = {
  SUPABASE_URL: '',
  SUPABASE_ANON_KEY: '',
  APP_NAME: 'البوفية',
  CURRENCY: 'ر.س'
};
